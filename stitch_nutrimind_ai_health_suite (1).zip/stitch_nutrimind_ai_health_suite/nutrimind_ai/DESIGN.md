---
name: NutriMind AI
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#d0bcff'
  on-tertiary: '#3c0091'
  tertiary-container: '#b090ff'
  on-tertiary-container: '#4600a7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.04em
  display-lg-mobile:
    fontFamily: Geist
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  label-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-padding-mobile: 20px
  container-padding-desktop: 48px
  gutter: 16px
  stack-gap-sm: 8px
  stack-gap-md: 16px
  stack-gap-lg: 32px
---

## Brand & Style

The design system is engineered for an ultra-premium, health-tech experience that fuses the clinical precision of high-end medical software with the fluid, evocative aesthetics of futuristic consumer electronics. It targets health-conscious high-performers who value data-driven insights delivered through a sophisticated, frictionless interface.

The visual style is a hybrid of **Minimalism** and **Glassmorphism**, characterized by "Precision-Crafted Depth." It leverages the high-fidelity finish of Apple’s interface guidelines with the technical, functional density found in developer-centric tools like Linear. The emotional response is one of absolute trust, quiet empowerment, and the feeling of interacting with a near-future intelligence.

**Key Visual Pillars:**
- **Luminous Glass:** Surfaces are treated as semi-transparent planes that catch light at the edges, creating a sense of physical layering without clutter.
- **Chromatic Precision:** AI interactions are distinguished by soft violet washes, differentiating human-input data from machine-generated insights.
- **Deep Obsidian Foundations:** The dark mode is not pure black but a layered obsidian, allowing for rich, vibrant color pops that don't cause eye strain.

## Colors

The palette is rooted in "Bio-Digital Vitality." It uses high-energy greens and blues to represent health and technology, set against a deep, premium background.

- **Emerald Green (Primary):** Represents organic growth, vitality, and "positive" health markers. Used for primary actions and success states.
- **Cyber Blue (Secondary):** Represents the analytical, AI-driven aspect of the platform. Used for data visualization and secondary technical cues.
- **Deep Obsidian (Background):** A base of `#0F172A` provides the canvas for glass effects and vibrant accents.
- **AI Violet (Accent):** Specifically reserved for AI-generated suggestions, "magic" buttons, and spark-based iconography.
- **Functional Gradients:** Use a linear gradient from Emerald to Cyber Blue (`45deg`) sparingly for premium features or progress indicators.

## Typography

This design system utilizes a dual-font strategy. **Geist** provides a technical, mono-spaced-adjacent feel for headlines and data labels, reinforcing the "AI" and "Analytical" nature of the product. **Inter** handles the heavy lifting of body text, ensuring maximum readability for complex nutritional data.

**Hierarchy Rules:**
- Use **Display** styles for hero metrics (e.g., daily calorie counts or health scores).
- **Labels** should always be uppercase with generous letter spacing to provide a "dashboard" feel.
- **Body** text remains neutral; let the layout and color drive the hierarchy, while the font provides the clarity.

## Layout & Spacing

The design system employs a **Fluid-Responsive Grid** based on an 8px base unit (with a 4px sub-grid for micro-adjustments).

**Mobile-First Implementation:**
- Content is primarily housed in floating cards with 20px side margins.
- Vertical rhythm is prioritized, with 32px gaps between major sections to maintain the premium, "breathable" feel.
- Bottom-sheet modals are preferred over full-screen transitions for secondary data input (e.g., logging food).

**Desktop Reflow:**
- Cards expand into a 12-column grid.
- Sidebars use a fixed width of 280px with a glass backdrop blur, while the main content area remains centered and maxed at 1200px to ensure readability.

## Elevation & Depth

Depth is conveyed through **Backdrop Blurs** and **Inner Glows** rather than traditional drop shadows.

- **Level 1 (Base):** Deep Obsidian (`#0F172A`).
- **Level 2 (Cards/Surfaces):** Background with 60% opacity and a `24px` backdrop blur. A `1px` stroke (white at 10% opacity) acts as a top-light rim.
- **Level 3 (Floating Actions/Modals):** Background with 80% opacity and `40px` blur. Shadows are replaced by a soft, colored outer glow (Emerald or Violet) with a 20% opacity and 30px spread to simulate light emission from the device.
- **Interactive States:** On hover or tap, the "inner glow" stroke should increase in brightness (opacity from 10% to 30%) to simulate a physical button being pressed toward a light source.

## Shapes

The shape language is "Squircle-influenced." It avoids sharp corners to maintain a friendly, organic health feel, but stops short of pill-shapes to retain its professional, software-first identity.

- **Standard Cards:** Use `1rem` (16px) corner radius.
- **Input Fields:** Match the card radius for a cohesive look.
- **Buttons:** Use `rounded-lg` (1rem) for a substantial, tactile feel.
- **Progress Bars:** Use fully rounded (capsule) ends to represent "flow" and organic movement.

## Components

**Buttons:**
- **Primary:** Gradient fill (Emerald to Cyber Blue) with white text. High-contrast and slightly larger than standard buttons.
- **AI Action:** Violet outline with a subtle inner glow. On click, trigger a "shimmer" animation across the button surface.

**Glass Cards:**
- Floating containers with a `1px` translucent border. Cards should appear to "hover" over the obsidian background. Use for health metrics, meal suggestions, and data charts.

**Inputs:**
- Dark, recessed fields with a `1px` border that glows Emerald Green when focused. Placeholder text should be a muted blue-gray.

**Chips/Badges:**
- Small, high-contrast pills. For "Macro" nutrients, use specific tints: Protein (Blue), Carbs (Violet), Fats (Green).

**AI Interaction Component:**
- A dedicated "Insight" card with a subtle animated violet border-gradient. This distinguishes AI-generated advice from static user data.

**Lists:**
- Borderless rows separated by a `1px` low-opacity line. Each row should have a subtle hover state that lifts the element using a 5% opacity increase.