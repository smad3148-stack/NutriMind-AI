/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PrismaClient } from '@prisma/client';

let prismaInstance: PrismaClient | null = null;
let isPrismaDisabled = false;

export function markPrismaDisabled(reason?: string) {
  if (!isPrismaDisabled) {
    isPrismaDisabled = true;
    console.log('[Storage] Active store: Supabase / In-Memory (Prisma fallback active)');
  }
  prismaInstance = null;
}

/**
 * Lazy initialization of server-side Prisma Client.
 * Prevents application startup crashes if DATABASE_URL is not set or invalid.
 */
export function getPrisma(): PrismaClient | null {
  if (isPrismaDisabled) return null;

  if (!prismaInstance) {
    const databaseUrl = process.env.DATABASE_URL;
    if (
      !databaseUrl ||
      databaseUrl.includes('your-db-password') ||
      databaseUrl.includes('your-project') ||
      databaseUrl.includes('YOUR_') ||
      databaseUrl.includes('INVALID') ||
      databaseUrl.trim() === ''
    ) {
      markPrismaDisabled('Invalid or placeholder DATABASE_URL detected');
      return null;
    }

    try {
      prismaInstance = new PrismaClient({
        datasources: {
          db: {
            url: databaseUrl,
          },
        },
      });
    } catch (err: any) {
      markPrismaDisabled('PrismaClient instantiation skipped');
      return null;
    }
  }

  return prismaInstance;
}

export function handlePrismaError(err: any, contextMsg: string) {
  markPrismaDisabled(`Fallback triggered for ${contextMsg}`);
}
