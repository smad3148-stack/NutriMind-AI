/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createClient } from '@supabase/supabase-js';
import * as dotenv from 'dotenv';

// Ensure environment variables are loaded with overrides in backend modules
dotenv.config({ override: true });

function bootstrapEnv() {
  // If env variables have merged space-separated values, parse and extract them.
  const envKeys = Object.keys(process.env);
  for (const key of envKeys) {
    const val = process.env[key];
    if (val && val.includes('=')) {
      const parts = val.split(/\s+/);
      for (const part of parts) {
        if (part.includes('=')) {
          const [subKey, subVal] = part.split('=');
          if (subKey && subVal) {
            let cleanedVal = subVal.trim();
            if (cleanedVal.startsWith('"') && cleanedVal.endsWith('"')) cleanedVal = cleanedVal.slice(1, -1);
            if (cleanedVal.startsWith("'") && cleanedVal.endsWith("'")) cleanedVal = cleanedVal.slice(1, -1);
            process.env[subKey] = cleanedVal.trim();
          }
        }
      }
      const firstPart = parts[0];
      if (firstPart && !firstPart.includes('=')) {
        process.env[key] = firstPart.trim();
      }
    }
  }
}
bootstrapEnv();

function sanitizeEnvValue(val: string | undefined): string {
  if (!val) return '';
  let cleaned = val.trim();
  
  // Strip outer quotes if present
  if (cleaned.startsWith('"') && cleaned.endsWith('"')) {
    cleaned = cleaned.slice(1, -1);
  }
  if (cleaned.startsWith("'") && cleaned.endsWith("'")) {
    cleaned = cleaned.slice(1, -1);
  }
  cleaned = cleaned.trim();

  // If it's a known placeholder, return empty
  if (
    cleaned.startsWith('(') || 
    cleaned.includes('Paste your') || 
    cleaned.includes('your-') || 
    cleaned.includes('your_') ||
    cleaned.length < 5
  ) {
    return '';
  }

  // Supabase keys must be JWTs (starting with eyJ) or begin with sb_ (newer client/admin keys). URL starts with http.
  if (!cleaned.startsWith('http') && !cleaned.startsWith('eyJ') && !cleaned.startsWith('sb_')) {
    return '';
  }
  
  return cleaned;
}

const supabaseUrl = sanitizeEnvValue(process.env.NEXT_PUBLIC_SUPABASE_URL) || sanitizeEnvValue(process.env.SUPABASE_URL) || '';
const supabaseServiceRoleKey = sanitizeEnvValue(process.env.SUPABASE_SERVICE_ROLE_KEY) || sanitizeEnvValue(process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY) || sanitizeEnvValue(process.env.SUPABASE_ANON_KEY) || '';

let supabaseAdminInstance: any = null;

/**
 * Lazy initialization of server-side Supabase Admin client.
 * Uses service role key to bypass Row Level Security for admin actions, telemetry logs,
 * webhook integrations, and critical microservice controls.
 * Falls back to anonymous key if service role is not present to prevent disabling backend features.
 * Returns any to prevent strict table types checks during build compilation.
 */
export function getSupabaseAdmin(): any {
  if (!supabaseAdminInstance) {
    if (!supabaseUrl || !supabaseServiceRoleKey) {
      console.warn('⚠️ [SERVER_WARNING] Supabase URL or Service/Anon Key is missing from environment variables. Initialize these keys in .env or Secrets to activate.');
      return null;
    }
    supabaseAdminInstance = createClient(supabaseUrl, supabaseServiceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false
      }
    });
  }
  return supabaseAdminInstance;
}
