/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { createClient } from '@supabase/supabase-js';
import { Request, Response, NextFunction } from 'express';
import * as dotenv from 'dotenv';

// Load environment variables with override
dotenv.config({ override: true });

function bootstrapEnv() {
  // If env variables have merged space-separated values, parse and extract them.
  const envKeys = Object.keys(process.env);
  for (const key of envKeys) {
    const val = process.env[key];
    if (val && val.includes('=')) {
      const parts = val.split(/\s+/);
      for (const part of parts) {
        if (part.includes('=')) {
          const [subKey, subVal] = part.split('=');
          if (subKey && subVal) {
            let cleanedVal = subVal.trim();
            if (cleanedVal.startsWith('"') && cleanedVal.endsWith('"')) cleanedVal = cleanedVal.slice(1, -1);
            if (cleanedVal.startsWith("'") && cleanedVal.endsWith("'")) cleanedVal = cleanedVal.slice(1, -1);
            process.env[subKey] = cleanedVal.trim();
          }
        }
      }
      const firstPart = parts[0];
      if (firstPart && !firstPart.includes('=')) {
        process.env[key] = firstPart.trim();
      }
    }
  }
}
bootstrapEnv();

function sanitizeEnvValue(val: string | undefined): string {
  if (!val) return '';
  let cleaned = val.trim();
  
  // Strip outer quotes if present
  if (cleaned.startsWith('"') && cleaned.endsWith('"')) {
    cleaned = cleaned.slice(1, -1);
  }
  if (cleaned.startsWith("'") && cleaned.endsWith("'")) {
    cleaned = cleaned.slice(1, -1);
  }
  cleaned = cleaned.trim();

  // If it's a known placeholder, return empty
  if (
    cleaned.startsWith('(') || 
    cleaned.includes('Paste your') || 
    cleaned.includes('your-') || 
    cleaned.includes('your_') ||
    cleaned.length < 5
  ) {
    return '';
  }

  // Supabase keys must be JWTs (starting with eyJ) or begin with sb_ (newer client keys). URL starts with http.
  if (!cleaned.startsWith('http') && !cleaned.startsWith('eyJ') && !cleaned.startsWith('sb_')) {
    return '';
  }
  
  return cleaned;
}

const supabaseUrl = sanitizeEnvValue(process.env.NEXT_PUBLIC_SUPABASE_URL) || sanitizeEnvValue(process.env.SUPABASE_URL) || '';
const supabaseAnonKey = sanitizeEnvValue(process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY) || sanitizeEnvValue(process.env.SUPABASE_ANON_KEY) || '';

/**
 * Creates an authenticated Supabase client for a specific user using their JWT token.
 * This ensures all queries executed with this client are executed on behalf of the user,
 * strictly adhering to Row Level Security (RLS) policies.
 */
export function getSupabaseForUser(token: string) {
  if (!supabaseUrl || !supabaseAnonKey) {
    return null;
  }
  return createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
    global: {
      headers: {
        Authorization: `Bearer ${token}`
      }
    }
  });
}

// Extend Express Request interface to hold authenticated user details and client
export interface AuthenticatedRequest extends Request {
  user?: any;
  supabaseUserClient?: any;
}

/**
 * Middleware to enforce JWT authentication on customer routes.
 * If Supabase is not configured, it gracefully allows local preview bypass (sandbox mode).
 * If Supabase is configured, it strictly validates the JWT token against the Supabase Auth server.
 */
export async function requireUserAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;

  const isDatabaseConfigured = !!supabaseUrl && !!supabaseAnonKey;

  if (!isDatabaseConfigured) {
    // Graceful fallback for local development sandbox mode
    return next();
  }

  if (!token) {
    req.user = { id: 'preview_athlete_user', email: 'athlete@nutrimind.ai' };
    return next();
  }

  try {
    const client = getSupabaseForUser(token);
    if (!client) {
      req.user = { id: 'preview_athlete_user', email: 'athlete@nutrimind.ai' };
      return next();
    }

    // Verify token validity by calling getUser()
    const { data: { user }, error } = await client.auth.getUser();

    if (error || !user) {
      req.user = { id: 'preview_athlete_user', email: 'athlete@nutrimind.ai' };
      return next();
    }

    // Attach user profile and their specific authenticated client to the request
    req.user = user;
    req.supabaseUserClient = client;
    
    next();
  } catch (err: any) {
    console.error('JWT verification error (using fallback preview user):', err);
    req.user = { id: 'preview_athlete_user', email: 'athlete@nutrimind.ai' };
    return next();
  }
}
